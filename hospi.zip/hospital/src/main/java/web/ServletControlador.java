package web;

import data.MedicamentosDAO;
import java.io.IOException;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.*;

@WebServlet("/servletControlador")
public class ServletControlador extends HttpServlet{
    
    @Override
    protected void doGet(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException{
        String accion = req.getParameter("accion");
        
        if(accion!=null){
            switch(accion){
                case "eliminar":
                    eliminarMedicamentos(req,res);
                    break;
                case "editar":
                    editarMedicamento(req, res);
                    break;
                default:
                    accionDefault(req, res);
                    break;
            }
        }else{
            accionDefault(req, res);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req , HttpServletResponse res)throws ServletException, IOException{
        String queryParam = req.getParameter("accion");
        if(queryParam!=null){
            switch(queryParam){
                case "insertar":
                    insertarMedicamento(req,res);
                    break;
                case "modificar":
                    modificarMedicamento(req,res);
                    break;
                default:
                    accionDefault(req,res);
                    break;
            }
        }
    }
    
    private void accionDefault(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException{
        List <Hospital> medicamentos = new MedicamentosDAO().findAll();
        medicamentos.forEach(System.out::println);
        HttpSession sesion = req.getSession();
        sesion.setAttribute("medicamentos", medicamentos);
        sesion.setAttribute("cantidadMedicamentos",calcularCajas(medicamentos));
        sesion.setAttribute("precioTotal", calcularPrecio(medicamentos));
//        req.getRequestDispatcher("medicamentos.jsp").forward(req, res);
        res.sendRedirect("medicamentos.jsp");
    }
    
    private void insertarMedicamento(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException{
        String nombre = req.getParameter("nombre");
        String laboratorio = req.getParameter("laboratorio");
        int cantComprimidos = Integer.parseInt(req.getParameter("cantComprimidos"));
        double precio = Double.parseDouble(req.getParameter("precio"));
        int cajas = Integer.parseInt(req.getParameter("cajas"));
        
        Hospital medicamento = new Hospital(nombre, laboratorio, cantComprimidos, precio, cajas);
        
        int registrosMod = new MedicamentosDAO().insert(medicamento);
        
        System.out.println("insertados = " + registrosMod);
        
        accionDefault(req, res);
    }
    
    private void eliminarMedicamentos(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException{
        int idMedicamento = Integer.parseInt(req.getParameter("idMedicamento"));
        
        int regMod = new MedicamentosDAO().deleteMedicamentos(idMedicamento);
        
        System.out.println("SE ELIMINARON: "+ regMod +" REGISTROS");
        
        accionDefault(req, res);
    }
    
    private void editarMedicamento(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException{
        int idMedicamento = Integer.parseInt(req.getParameter("idmedicamento"));
        Hospital medicamento = new MedicamentosDAO().findById(idMedicamento);
        req.setAttribute("medicamento", medicamento);
        String jspEditar = "/WEB-INF/paginas/operaciones/editar.jsp";
        req.getRequestDispatcher(jspEditar).forward(req, res);
    }
    
    private void modificarMedicamento(HttpServletRequest req , HttpServletResponse res)throws ServletException, IOException{
        String nombre = req.getParameter("nombre");
        String laboratorio = req.getParameter("laboratorio");
        int cantComprimidos = Integer.parseInt(req.getParameter("cantComprimidos"));
        double precio = Double.parseDouble(req.getParameter("precio"));
        int cajas = Integer.parseInt(req.getParameter("cajas"));
        
        int idMedicamento = Integer.parseInt(req.getParameter("idMedicamento"));
        
        Hospital med = new Hospital(idMedicamento,nombre,laboratorio,cantComprimidos,precio,cajas);
        
        int regMod = new MedicamentosDAO().update(med);
        
        System.out.println("SE ACTUALIZARON: "+ regMod +" REGISTROS");
        
        accionDefault(req, res);
    }
    
    private int calcularCajas(List<Hospital> med){
        int cant=0;
        for (int i = 0; i < med.size(); i++) {
            cant += med.get(i).getCajas();
        }
        return cant;
    }
    
    private double calcularPrecio(List<Hospital> med){
        double precio = 0;
        for (int i = 0; i < med.size(); i++) {
            precio += (med.get(i).getPrecio() * med.get(i).getCajas());
        }
        return precio;
    }
}

package model;

public class Hospital {
    private int idmedicamento;
    private String nombre;
    private String laboratorio;
    private int cantComprimidos;
    private double precio;
    private int cajas;

    public Hospital(int idmedicamento, String nombre, String laboratorio, int cantComprimidos, double precio, int cajas) {
        this.idmedicamento = idmedicamento;
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.cantComprimidos = cantComprimidos;
        this.precio = precio;
        this.cajas = cajas;
    }

    public Hospital(String nombre, String laboratorio, int cantComprimidos, double precio, int cajas) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.cantComprimidos = cantComprimidos;
        this.precio = precio;
        this.cajas = cajas;
    }

    public int getIdmedicamento() {
        return idmedicamento;
    }

    public void setIdmedicamento(int idmedicamento) {
        this.idmedicamento = idmedicamento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLaboratorio() {
        return laboratorio;
    }

    public void setLaboratorio(String laboratorio) {
        this.laboratorio = laboratorio;
    }

    public int getCantComprimidos() {
        return cantComprimidos;
    }

    public void setcantComprimidos(int cantComprimidos) {
        this.cantComprimidos = cantComprimidos;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCajas() {
        return cajas;
    }

    public void setCajas(int cajas) {
        this.cajas = cajas;
    }

    @Override
    public String toString() {
        return "Medicamento{" + "nombre=" + nombre + ", laboratorio=" + laboratorio + ", cantComprimidos=" + cantComprimidos + ", precio=" + precio + ", cajas=" + cajas + '}';
    }
}

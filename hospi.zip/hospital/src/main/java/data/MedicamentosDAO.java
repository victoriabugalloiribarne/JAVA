package data;

import static data.Conexion.*;
import java.sql.*;
import java.util.*;
import model.Hospital;

public class MedicamentosDAO {
    private static final String SQL_CREATE="INSERT INTO medicamentos(nombre, laboratorio, cantComprimidos, precio, cajas) VALUES(?, ?, ?, ?, ?)";
    private static final String SQL_READ="SELECT * FROM medicamentos";
    private static final String SQL_READ_BY_ID= "SELECT * FROM medicamentos WHERE idmedicamentos= ?";
    private static final String SQL_UPDATE_PRECIO="UPDATE medicamentos SET precio = ? WHERE idmedicamentos = ?";
    private static final String SQL_UPDATE_COPIAS="UPDATE medicamentos SET cajas = ? WHERE idmedicamentos = ?";
    private static final String SQL_UPDATE="UPDATE medicamentos SET nombre = ?, laboratorio = ?, cantComprimidos = ?, precio = ?,cajas = ? WHERE idmedicamentos = ?";
    private static final String SQL_DELETE="DELETE FROM medicamentos WHERE idmedicamentos = ?";
    
    
    public List<Hospital> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Hospital medicamento ;
        List<Hospital> medicamentos = new ArrayList();

        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_READ);
            rs = stmt.executeQuery();
            while (rs.next()) {
                
                int idmedicamentos = rs.getInt(1);
                String nombre = rs.getString(2);
                String laboratorio = rs.getString(3);
                int cantComprimidos = rs.getInt(4);
                double precio = rs.getDouble(5);
                int cajas = rs.getInt(6);

                medicamento = new Hospital(idmedicamentos, nombre, laboratorio,cantComprimidos,precio,cajas);

                medicamentos.add(medicamento);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                close(rs);
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }

        return medicamentos;
    }
    
    public Hospital findById(int id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Hospital medicamento = null;
        
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_READ_BY_ID);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                int idmedicamentos = rs.getInt(1);
                String nombre = rs.getString(2);
                String laboratorio = rs.getString(3);
                int cantComprimidos = rs.getInt(4);
                double precio = rs.getDouble(5);
                int cajas = rs.getInt(6);

                medicamento = new Hospital(idmedicamentos, nombre, laboratorio,cantComprimidos,precio,cajas);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                close(rs);
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return medicamento;
    }
    
    
    
    public int insert(Hospital medicamento){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_CREATE);
            stmt.setString(1, medicamento.getNombre());
            stmt.setString(2, medicamento.getLaboratorio());
            stmt.setInt(3, medicamento.getCantComprimidos());
            stmt.setDouble(4, medicamento.getPrecio());
            stmt.setInt(5, medicamento.getCajas());
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    public int updatePrecio(Hospital medicamento){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_UPDATE_PRECIO);
            stmt.setDouble(1, medicamento.getPrecio());
            stmt.setInt(2, medicamento.getIdmedicamento());
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    public int updateCajas(Hospital medicamento){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_UPDATE_COPIAS);
            stmt.setInt(1, medicamento.getCajas());
            stmt.setInt(2, medicamento.getIdmedicamento());
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    public int update(Hospital medicamento){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, medicamento.getNombre());
            stmt.setString(2, medicamento.getLaboratorio());
            stmt.setInt(3, medicamento.getCantComprimidos());
            stmt.setDouble(4, medicamento.getPrecio());
            stmt.setInt(5, medicamento.getCajas());
            stmt.setInt(6, medicamento.getIdmedicamento());
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    public int deleteMedicamentos(int id){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, id);
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
}
